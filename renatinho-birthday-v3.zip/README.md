# Renatinho Birthday — V3

Base original preservada e expandida com estética Y2K/Flash e Card Factory.

## Novidades
- brilho/relevo e reflexos;
- emojis flutuantes;
- RENATINHO CARD FACTORY;
- preview em tempo real;
- temas e animações;
- emojis/stickers;
- efeitos;
- música por arquivo ou link de YouTube/Spotify;
- exportação de configuração `.json`.

## Fluxo dos amigos
Abrir o site → CARD MAKER → preencher → exportar → mandar o `.json` para a pessoa que administra o GitHub.

Observação: o JSON registra o link/nome do áudio; arquivos locais precisam ser incluídos no repositório para funcionarem depois.
